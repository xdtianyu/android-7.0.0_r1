import pkg1.pkg2.foo
print "  Finished importing pkg1.pkg2.foo"
var2 = pkg1.pkg2.foo.Pkg2_Foo();
print "  Successfully created object pkg1.pkg2.foo.Pkg2_Foo"
