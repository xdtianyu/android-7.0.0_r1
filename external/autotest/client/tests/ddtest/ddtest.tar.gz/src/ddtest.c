/*
 * Copyright (c) 2010 The Chromium OS Authors. All rights reserved.
 * Use of this source code is governed by a BSD-style license that can be
 * found in the LICENSE file.
 */
#define _GNU_SOURCE
#define _XOPEN_SOURCE 600

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <assert.h>
#include <string.h>
#include <time.h>

int run_dd(int number, char *dirname, int blocksize, int blocknum)
{
       int fd;
       int pid;
       int i;
       int ecode = 0;
       char fname[1024];
       char *kilo = NULL;

       fflush(stdout);
       fflush(stderr);
       pid = fork();

       if (pid < 0)
               return -1;
       if (pid != 0)
               return pid;

       if (posix_memalign((void *) &kilo, 512, blocksize) != 0)
               _exit(1);
       snprintf(fname, sizeof(fname), "%s/tf%d", dirname, number);
       fd = open(fname, O_WRONLY | O_CREAT);
       if (fd < 0)
               _exit(2);
       for (i = 0; i < blocknum; i++) {
               if (write(fd, kilo, blocksize) != blocksize) {
                       ecode = 3;
                       break;
               }
       }
       fdatasync(fd);
       close(fd);
       free(kilo);
       _exit(ecode);
       return 0;
}

void cleanup(int threadnum, char *dirname)
{
       int i;
       char fname[1024];

       for (i = 0; i < threadnum; i++) {
               snprintf(fname, sizeof(fname), "%s/tf%d",
                       dirname, i);
               unlink(fname);
       }
}

void usage(char* appname)
{
       printf("Usage: %s\n", appname);
       printf("     -D dirpath       directory path to use\n");
       printf("    [-b blocksize]    size of blocks to write    (1024)\n");
       printf("    [-n blocknum]     number of blocks to write  (1024)\n");
       printf("    [-t threads]      number of parallel threads (20)\n");
       printf("\n");
}

int main(int argc, char **argv)
{
       time_t start_time;
       time_t end_time;
       double wbytes;
       int blocksize = 1024;
       int blocknum = 1024;
       int threadnum = 20;
       int children = 0;
       int opt;
       int i;
       int rval;
       int pid;
       int good = 1;
       int exit_val = 0;
       char* appname = argv[0];
       char* dirname = NULL;

       while ((opt = getopt(argc, argv, "D:b:n:t:")) != -1) {
               switch (opt) {
                       case 'D':
                               dirname = optarg;
                               break;
                       case 'b':
                               blocksize = atoi(optarg);
                               break;
                       case 'n':
                               blocknum = atoi(optarg);
                               break;
                       case 't':
                               threadnum = atoi(optarg);
                               break;
                       default:
                               usage(appname);
                               exit(exit_val);
               }
       }
       argc -= optind;
       argv += optind;

       if (dirname == NULL) {
               fprintf(stderr, "%s: -D dir_path argument required\n", appname);
               return EXIT_FAILURE;
       }
       if ((blocksize & (blocksize - 1)) != 0) {
               fprintf(stderr, "%s: block size must be a power of two\n",
                       appname);
               return EXIT_FAILURE;
       }
       if ((blocksize % sizeof(void *)) != 0) {
               fprintf(stderr, "%s: block size must be a multiple of %d\n",
                       appname, sizeof(void *));
               return EXIT_FAILURE;
       }

       wbytes = (double) blocksize;
       wbytes *= (double) blocknum;
       wbytes *= (double) threadnum;

       printf("directory path is %s\n", appname, dirname);
       printf("blocksize is %d\n", blocksize);
       printf("blocknum is %d\n", blocknum);
       printf("threadnum is %d\n", threadnum);
       printf("write total is %5.2f MB\n", wbytes / 1048576.0);

       start_time = time(NULL);

       for (i = 0; i < threadnum; i++) {
               rval = run_dd(i, dirname, blocksize, blocknum);
               if (rval < 0) {
                       fprintf(stderr, "%s: thread %d failed to launch\n",
                               appname, i);
                       good = 0;
                       exit_val = 102;
               } else
                       children++;
       }

       while (children > 0) {
               pid = wait(&rval);
               if (!WIFEXITED(rval)) {
                       fprintf(stderr,
                               "%s: thread terminated abnormally\n",
                               appname);
                       good = 0;
                       exit_val = 100;
               } else if (WEXITSTATUS(rval) == 1) {
                       fprintf(stderr,
                               "%s: thread failed to allocate memory\n",
                               appname);
                       good = 0;
                       exit_val = 1;
               } else if (WEXITSTATUS(rval) == 2) {
                       fprintf(stderr, "%s: thread failed to open file\n",
                               appname);
                       good = 0;
                       exit_val = 2;
               } else if (WEXITSTATUS(rval) == 3) {
                       fprintf(stderr, "%s: thread failed to write file\n",
                               appname);
                       good = 0;
                       exit_val = 3;
               } else if (WEXITSTATUS(rval) != 0) {
                       fprintf(stderr,
                               "%s: thread failed for unknown reason (%d)\n",
                               appname, WEXITSTATUS(rval));
                       good = 0;
                       exit_val = 101;
               }
               children--;
       }

       end_time = time(NULL);

       if ((good != 0) && (end_time > start_time)) {
               printf("throughput is %5.2f MB/sec\n",
                      (wbytes / 1048576.0) / (end_time - start_time));
       }

       cleanup(threadnum, dirname);
       exit(exit_val);
}
